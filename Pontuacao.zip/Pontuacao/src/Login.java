public class Login {

    private Pontuacao pontuacao = new Pontuacao();

    
    public boolean login(String usuario, String senha) {
       
        
        boolean autenticadoComSucesso = true; 

        if (autenticadoComSucesso) {
            pontuacao.atualizarPontuacao(usuario, 10);
            return true;
        } else {
            return false;
        }
    }
}
